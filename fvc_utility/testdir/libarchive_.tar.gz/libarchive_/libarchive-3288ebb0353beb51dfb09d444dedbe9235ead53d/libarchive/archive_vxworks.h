/* archive_vxworks.h - libarchive VxWorks header file */

/*
 * Copyright (c) 2017, 2020-2021 Wind River Systems, Inc.
 *
 * The right to copy, distribute, modify or otherwise make use
 * of this software may be licensed only pursuant to the terms
 * of an applicable Wind River license agreement.
 */

#ifndef LIBARCHIVE_ARCHIVE_VXWORKS_H_INCLUDED
#define LIBARCHIVE_ARCHIVE_VXWORKS_H_INCLUDED

#include <vxWorks.h>
#include <stdio.h>

#ifndef S_ISVTX
#define S_ISVTX  0001000
#endif

#ifndef id_t
#define id_t unsigned int
#endif

#ifndef getpwuid
#define getpwuid(id) NULL
#endif

/* Redefine passwd here as UNIX pwd.h is empty */

struct passwd
    {
    char * pw_name;  /* User's login name */
    uid_t  pw_uid;   /* Numerical user ID */
    gid_t  pw_gid;   /* Numerical group ID - UNUSED AND RESERVED */
    char * pw_dir;   /* Initial working directory - UNUSED */
    char * pw_shell; /* Program to use as shell - UNUSED */
    };

#endif /* LIBARCHIVE_ARCHIVE_VXWORKS_H_INCLUDED */
